M1 update:
- InputManager (tap/space)
- Moving "current block" oscillating left-right
- Drop on tap; detect landing (sleep) and auto-spawn next block
- Simple +10 score per landed block (stacking rules come in M2)
