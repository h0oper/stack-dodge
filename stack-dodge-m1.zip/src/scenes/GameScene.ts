import Phaser from 'phaser'
import { InputManager } from '@/managers/InputManager'

type DropState = 'moving' | 'falling' | 'landed'

export class GameScene extends Phaser.Scene {
  private ground!: MatterJS.BodyType
  private mover!: Phaser.Physics.Matter.Image
  private moverTween?: Phaser.Tweens.Tween
  private inputMgr!: InputManager
  private state: DropState = 'moving'
  private score = 0
  private scoreText!: Phaser.GameObjects.Text

  constructor() { super({ key: 'GameScene' }) }

  create(): void {
    const { width, height } = this.scale
    this.add.image(width/2, height/2, 'bg').setDisplaySize(width, height)

    // Ground
    const groundWidth = width * 0.9
    const groundY = height - 60
    this.ground = this.matter.add.rectangle(width/2, groundY, groundWidth, 40, { isStatic: true })
    const gfx = this.add.rectangle(width/2, groundY, groundWidth, 40, 0x2c3e50, 0.15)
    gfx.setStrokeStyle(2, 0x2c3e50, 0.5)

    // Score
    this.scoreText = this.add.text(20, 20, 'Score: 0', { fontSize: '22px', color: '#2C3E50' })

    // Input
    this.inputMgr = new InputManager(this)
    this.events.on('input:tap', this.onTap, this)

    // First block
    this.spawnMovingBlock()
  }

  private spawnMovingBlock() {
    const { width } = this.scale
    const yStart = 160
    const xStart = width * 0.2

    // Alternate colors just for visual variety
    const keys = ['block_red', 'block_blue', 'block_green']
    const key = keys[this.score % keys.length]

    this.mover = this.matter.add.image(xStart, yStart, key, undefined, {
      ignoreGravity: true,
      chamfer: 4
    })
    this.mover.setRectangle(60, 30) // precise collider
    this.mover.setFrictionAir(0.002)
    this.mover.setBounce(0.05)

    // Ping-pong tween left<->right
    this.moverTween?.stop()
    this.moverTween = this.tweens.add({
      targets: this.mover,
      x: { from: width * 0.2, to: width * 0.8 },
      duration: 1400,
      ease: 'Sine.inOut',
      yoyo: true,
      repeat: -1
    })

    this.state = 'moving'

    // Help text (one-time)
    if (this.score === 0) {
      const tip = this.add.text(width/2, 110, 'Tap to drop', { fontSize: '18px', color: '#2C3E50' }).setOrigin(0.5)
      this.time.delayedCall(2400, () => tip.destroy())
    }
  }

  private onTap() {
    if (this.state !== 'moving') return
    // Drop: enable gravity, stop tween
    this.moverTween?.stop()
    this.mover.setIgnoreGravity(false)
    this.state = 'falling'

    // When it settles (sleep) consider it landed and respawn
    this.matter.world.on('sleepstart', (body: MatterJS.BodyType) => {
      if (body === this.mover.body && this.state === 'falling') {
        this.handleLanded()
      }
    })
  }

  private handleLanded() {
    this.state = 'landed'
    // Increment simple score for M1
    this.score += 10
    this.scoreText.setText(`Score: ${this.score}`)

    // Spawn new moving block after short delay
    this.time.delayedCall(500, () => this.spawnMovingBlock())
  }

  shutdown(): void {
    this.events.off('input:tap', this.onTap, this)
    this.inputMgr?.destroy()
  }
}
